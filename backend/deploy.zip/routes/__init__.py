from .user_routes import user_ns
from .workout_routes import workout_ns
from .auth_routes import auth_ns
