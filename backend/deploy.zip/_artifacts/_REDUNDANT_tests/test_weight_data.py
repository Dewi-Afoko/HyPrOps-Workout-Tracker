# import pytest
# from datetime import datetime

# def test_weight_data_object_creates_with_values_provided():
#     weight_data = WeightData(weight=85, date=datetime.strptime("2024/12/27", "%Y/%m/%d"))
#     assert weight_data.weight == 85
#     assert weight_data.date.strftime("%Y/%m/%d") == "2024/12/27"